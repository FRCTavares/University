docker-compose up -d
python main.py

depois 
http://localhost:3000/

user : admin
pass: admin

depois ir aba dashboard/Satellite Telemetry - Sensors Only

depois em cada grafico ir em editar (clicar com o "e"  por cima e embaixo do ecrã clicar em run Query)
