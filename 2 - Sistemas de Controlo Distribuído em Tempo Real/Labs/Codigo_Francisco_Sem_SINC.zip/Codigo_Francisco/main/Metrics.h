#ifndef METRICS_H
#define METRICS_H

void computeAndPrintMetrics();
float computeEnergyFromBuffer();
float computeVisibilityErrorFromBuffer();
float computeFlickerFromBuffer();

#endif
