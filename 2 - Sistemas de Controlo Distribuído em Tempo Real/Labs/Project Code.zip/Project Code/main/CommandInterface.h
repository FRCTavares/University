#ifndef COMMANDINTERFACE_H
#define COMMANDINTERFACE_H

void processSerialCommands();

#endif
