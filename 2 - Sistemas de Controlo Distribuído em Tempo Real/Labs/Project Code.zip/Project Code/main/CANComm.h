#ifndef CANCOMM_H
#define CANCOMM_H

#include <Arduino.h>
#include "mcp2515.h"  // Ensure you have the MCP2515 library available

// Define a type for a callback function to handle received CAN messages.
typedef void (*CANMessageCallback)(const struct can_frame &frame);

// Initialize the CAN interface.
void initCANComm();

// Process incoming CAN messages (nonblocking; call this in your loop).
void canCommLoop();

// Send a CAN message. Returns the MCP2515 error code.
MCP2515::ERROR sendCANMessage(const can_frame &frame);

// CANComm.h
MCP2515::ERROR readCANMessage(struct can_frame *frame);

// Register a callback function to be called when a CAN message is received.
void setCANMessageCallback(CANMessageCallback callback);

#endif
