#include "CANComm.h"
#include <SPI.h>

// Instantiate the MCP2515 object.
// Adjust the parameters to match your wiring and board.
// For example, here we assume SPI0 with:
// CS on pin 10, TX on pin 11, RX on pin 12, SCK on pin 13, and a clock speed of 10MHz.
MCP2515 can0(spi0, 10, 11, 12, 13, 10000000);

// Static variable to hold the registered callback.
static CANMessageCallback messageCallback = nullptr;

void initCANComm() {
  // Reset the CAN module.
  if (can0.reset() != MCP2515::ERROR_OK) {
    Serial.println("CANComm: Reset failed!");
  }
  
  // Set bitrate to 1000 kbps using a 16MHz clock (adjust if necessary).
  if (can0.setBitrate(CAN_1000KBPS, MCP_16MHZ) != MCP2515::ERROR_OK) {
    Serial.println("CANComm: setBitrate failed!");
  }
  
  // Set the module to normal mode (for loopback testing you could use setLoopbackMode()).
  if (can0.setNormalMode() != MCP2515::ERROR_OK) {
    Serial.println("CANComm: setNormalMode failed!");
  }
  
  Serial.println("CANComm: CAN initialized in normal mode.");
}

void canCommLoop() {
  // Nonblocking check: if a message is available, process it.
  can_frame msg;
  if (can0.readMessage(&msg) == MCP2515::ERROR_OK) {
    // If a callback has been registered, call it.
    if (messageCallback) {
      messageCallback(msg);
    } else {
      // Otherwise, for demonstration, print the received message.
      Serial.print("CAN Received - ID: 0x");
      Serial.print(msg.can_id, HEX);
      Serial.print(" DLC: ");
      Serial.print(msg.can_dlc);
      Serial.print(" Data: ");
      for (uint8_t i = 0; i < msg.can_dlc; i++) {
        Serial.print(msg.data[i], HEX);
        Serial.print(" ");
      }
      Serial.println();
    }
  }
}

MCP2515::ERROR sendCANMessage(const can_frame &frame) {
  // Send the message using the MCP2515 object.
  MCP2515::ERROR err = can0.sendMessage(&frame);
  return err;
}

// CANComm.cpp
MCP2515::ERROR readCANMessage(struct can_frame *frame) {
  return can0.readMessage(frame);  // calls the MCP2515 object's readMessage()
}


void setCANMessageCallback(CANMessageCallback callback) {
  // Register the callback function.
  messageCallback = callback;
}
