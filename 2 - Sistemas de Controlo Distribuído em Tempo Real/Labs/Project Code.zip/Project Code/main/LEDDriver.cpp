#include "LEDDriver.h"

// Static variables for the module
static int ledPin = -1;
static int pwmMax = 4095;
static int pwmMin = 0;
static float currentDutyCycle = 0.0;
static float maxPowerWatts = 1.0;

// --- PWM Configuration Constants ---
// 30kHz frequency selected for:
// 1. Well above human flicker perception (~100Hz)
// 2. Optimal for power efficiency with this LED driver
// 3. High enough for smooth dimming without visible steps
const unsigned int PWM_FREQUENCY = 30000;

/**
 * Initialize LED driver with appropriate pin and settings
 * Sets up PWM frequency and resolution for optimal performance
 */
void initLEDDriver(int pin) {
    ledPin = pin;
    pinMode(ledPin, OUTPUT);
    
    // Configure PWM with optimal settings for this LED system
    analogWriteRange(pwmMax);
    analogWriteFreq(PWM_FREQUENCY);
    
    // Start with LED off
    analogWrite(ledPin, pwmMin);
    currentDutyCycle = 0.0;
}

/**
 * Set LED brightness using duty cycle [0.0-1.0]
 */
void setLEDDutyCycle(float dutyCycle) {
    // Validate and constrain input
    if (isnan(dutyCycle) || isinf(dutyCycle)) {
        return; // Protect against invalid inputs
    }
    
    // Constrain to valid range
    dutyCycle = constrain(dutyCycle, 0.0f, 1.0f);
    
    // Apply duty cycle
    int pwmValue = (int)(dutyCycle * pwmMax);
    analogWrite(ledPin, pwmValue);
    
    // Save current value
    currentDutyCycle = dutyCycle;
}

/**
 * Set LED brightness using percentage [0-100]
 */
void setLEDPercentage(float percentage) {
    // Validate and constrain input
    percentage = constrain(percentage, 0.0f, 100.0f);
    
    // Convert to duty cycle and apply
    float dutyCycle = percentage / 100.0f;
    setLEDDutyCycle(dutyCycle);
}

/**
 * Set LED brightness using direct PWM value [0-PWM_MAX]
 */
void setLEDPWMValue(int pwmValue) {
    // Validate and constrain input
    pwmValue = constrain(pwmValue, pwmMin, pwmMax);
    
    // Apply PWM value
    analogWrite(ledPin, pwmValue);
    
    // Update duty cycle
    currentDutyCycle = (float)pwmValue / pwmMax;
}

/**
 * Set LED brightness using power in watts [0-MAX_POWER_WATTS]
 * Note: Assumes a linear relationship between duty cycle and power
 */
void setLEDPower(float powerWatts) {
    // Validate and constrain input
    powerWatts = constrain(powerWatts, 0.0f, maxPowerWatts);
    
    // Convert to duty cycle and apply
    float dutyCycle = powerWatts / maxPowerWatts;
    setLEDDutyCycle(dutyCycle);
}

/**
 * Get current LED duty cycle [0.0-1.0]
 */
float getLEDDutyCycle() {
    return currentDutyCycle;
}

/**
 * Get current LED percentage [0-100]
 */
float getLEDPercentage() {
    return currentDutyCycle * 100.0f;
}

/**
 * Get current LED PWM value [0-PWM_MAX]
 */
int getLEDPWMValue() {
    return (int)(currentDutyCycle * pwmMax);
}

/**
 * Get current LED power in watts [0-MAX_POWER_WATTS]
 */
float getLEDPower() {
    return currentDutyCycle * maxPowerWatts;
}

/**
 * Perform smooth transition to target brightness over specified time
 */
void smoothTransition(float targetDutyCycle, int transitionTimeMs) {
    // Validate inputs
    targetDutyCycle = constrain(targetDutyCycle, 0.0f, 1.0f);
    if (transitionTimeMs <= 0) {
        setLEDDutyCycle(targetDutyCycle);
        return;
    }
    
    // Calculate parameters
    float startDuty = currentDutyCycle;
    float dutyDelta = targetDutyCycle - startDuty;
    unsigned long startTime = millis();
    unsigned long currentTime;
    float progress;
    
    // Perform transition
    do {
        currentTime = millis();
        progress = (float)(currentTime - startTime) / transitionTimeMs;
        progress = constrain(progress, 0.0f, 1.0f);
        
        // Calculate intermediate duty cycle
        float intermediateDuty = startDuty + (dutyDelta * progress);
        setLEDDutyCycle(intermediateDuty);
        
        delay(5); // Short delay to not block completely
        
    } while (progress < 1.0f);
}

/**
 * Create a pulse effect between min and max brightness
 */
void pulseEffect(int durationMs, float minDuty, float maxDuty) {
    minDuty = constrain(minDuty, 0.0f, 1.0f);
    maxDuty = constrain(maxDuty, 0.0f, 1.0f);
    
    // Remember original duty cycle
    float originalDuty = currentDutyCycle;
    
    // Perform pulse up and down
    smoothTransition(maxDuty, durationMs / 2);
    smoothTransition(minDuty, durationMs / 2);
    
    // Restore original brightness
    smoothTransition(originalDuty, durationMs / 4);
}