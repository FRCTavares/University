import serial
import time

# Configure the serial port (replace 'COM3' with your port)
robot = serial.Serial(
    port='COM7',      # Serial port (adjust as needed)
    baudrate=9600,    # Match the robot's baud rate
    timeout=2,         # Timeout in seconds
    parity=serial.PARITY_NONE,
    stopbits=1,
    bytesize=8,
    xonxoff=True
)

def angles(a1,a2,a3,a4,a5):
    m1=(31960+31950)/250
    r1=m1*a1
    m2=(16960+25972)/170
    r2=m2*a2
    m3=(28480+28942)/225
    r3=m3*a3
    m4=(27048+28133)/180
    r4=m4*a4
    m5=(31929+31956)/360
    r5=m5*a5
    return r1,r2,r3,r4,r5

# Function to send a command to the robot
def send_command(command):
    if robot.is_open:
        robot.write((command + '\r').encode())  # Send command with newline
        #robot.write((command).encode())  # Send command with newline
        time.sleep(1)
        for i in range(0,4):                         # Allow time for execution
            response = robot.readline().decode().strip()  # Read response
            print(f"Robot Response: {response}")
            time.sleep(0.1)
        return response
    else:
        print("Error: Serial port not open.")
        return None

# Example commands (replace with actual Scorbot commands)
try:
    #send_command("HELP")
    # Send a command to move Joint 1 to 45 degrees
    #send_command("MOVE J1 45")
    #send_command("CON")
    # Command to open the gripper
    #send_command("HOME")
    a1,a2,a3,a4,a5=angles(-90,90,0,0,90)
    print(a1,a2,a3,a4,a5)
    send_command("HERE G1101")
    send_command("SPEED 5")
    send_command("LISTPV G1101")
    #referencial
    send_command("SETPV G1101 2 11000")
    send_command("MOVE G1101")
    send_command("LISTPV G1101")
    send_command("SETPV G1101 3 8000")
    send_command("MOVE G1101")
    send_command("LISTPV G1101")
    send_command("SETPV G1101 4 27500")
    send_command("MOVE G1101")
    send_command("LISTPV G1101")
    time.sleep(5)
    #1 ROTATION
    send_command("SETPV G1101 1 -23007")
    send_command("MOVE G1101")
    send_command("LISTPV G1101")
    send_command("SETPV G1101 4 -90")
    send_command("MOVE G1101")
    send_command("LISTPV G1101")
    send_command("SETPV G1101 5 -9200")
    send_command("MOVE G1101")
    send_command("LISTPV G1101")
    time.sleep(5)
    #2 ROTATION
    send_command("SETPV G1101 1 0")
    send_command("MOVE G1101")
    send_command("LISTPV G1101")
    #send_command("DELP G1101")

    # Command to move to a specific position
    #send_command("MOVE POS X=100 Y=50 Z=20")

except Exception as e:
    print(f"An error occurred: {e}")
finally:
    robot.close()  # Always close the serial port when done