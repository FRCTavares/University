from sympy import symbols, sin, cos, Matrix, Eq, solve,simplify
# Define the angles as symbols
a1, a2, a3, a4, a5 = symbols('a1 a2 a3 a4 a5')

# First matrix T1
T1 = Matrix([
    [cos(a1), -sin(a1), 0, 0],
    [sin(a1), cos(a1), 0, 0],
    [0, 0, 1, 0],
    [0, 0, 0, 1]
])

# Second matrix T2
T2 = Matrix([
    [cos(a2), -sin(a2), 0, 0.05],
    [0, 0, 1, 0.3585],
    [-sin(a2), -cos(a2), 0, 0],
    [0, 0, 0, 1]
])

# Third matrix T3
T3 = Matrix([
    [cos(a3), -sin(a3), 0, 0.3],
    [sin(a3), cos(a3), 0, 0],
    [0, 0, 1, 0],
    [0, 0, 0, 1]
])

# Fourth matrix T4
T4 = Matrix([
    [cos(a4), -sin(a4), 0, 0.35],
    [sin(a4), cos(a4), 0, 0],
    [0, 0, 1, 0],
    [0, 0, 0, 1]
])

# Fifth matrix T5
T5 = Matrix([
    [cos(a5), -sin(a5), 0, 0.35],
    [0, 0, 1, 0.251],
    [-sin(a5), -cos(a5), 0, 0],
    [0, 0, 0, 1]
])

# Multiply all the matrices
result = T1*T2*T3*T4*T5
#print(result)
# Simplify the result (optional, to make the expression more readable)
result = simplify(result)
print(result)
# Extract the top-left 3x3 portion of the matrix
robot_matrix = result[:3, :3]
# Define the target matrix (X_mat)
X_mat = Matrix([
    [1, 0, 0],
    [0, 0, -1],
    [0, 1, 0]
])
Y_mat = Matrix([
    [0, 0, 1],
    [0, 1, 0],
    [-1, 0, 0]
])

# Create equations by equating corresponding elements of robot_matrix and X_mat
equations = []
for i in range(3):
    for j in range(3):
        equations.append(Eq(robot_matrix[i, j], X_mat[i, j]))

# Solve for the angles a1, a2, a3, a4, a5
solution = solve(equations, (a1, a2, a3, a4, a5))

# Print the solutions
print(solution)
Y_mat=X_mat*Y_mat
equations = []
for i in range(3):
    for j in range(3):
        equations.append(Eq(robot_matrix[i, j], Y_mat[i, j]))

# Solve for the angles a1, a2, a3, a4, a5
solution = solve(equations, (a1, a2, a3, a4, a5))
print(solution)