#include <Arduino.h>
#include <math.h>
#include <map>
#include <algorithm>
#include "pico/multicore.h"

#include "Globals.h"
#include "CANComm.h"
#include "LEDDriver.h"
#include "Calibration.h"
#include "SensorManager.h"
#include "PIController.h"

extern float readLux();
extern void setLEDDutyCycle(float dutyCycle);
extern bool sendControlCommand(uint8_t destAddr, uint8_t controlType, float value);
extern bool sendSensorReading(uint8_t destAddr, uint8_t sensorType, float value);

std::vector<uint8_t> calibrationQueue;
unsigned long lastCalibrationTime = 0;

/**
 * Start self-calibration process in a decentralized manner
 * Each node calibrates itself without a master node coordinating
 */
void startSelfCalibration() {
    uint8_t myNodeId = deviceConfig.nodeId;
    
    // Check if we've already calibrated during this wake-up cycle
    critical_section_enter_blocking(&commStateLock);
    if (commState.hasPerformedCalibration) {
        Serial.println("Already calibrated during this wake-up cycle. Ignoring redundant request.");
        critical_section_exit(&commStateLock);
        return;
    }
    
    // Mark that we're now calibrating to prevent future calls
    commState.hasPerformedCalibration = true;
    commState.calibrationState = CAL_MEASURING_SELF;
    critical_section_exit(&commStateLock);
    
    // Double-check to avoid simultaneous calibration
    critical_section_enter_blocking(&commStateLock);
    bool canStartCalibration = (commState.activeCalibrationNode == 0 || 
                               commState.activeCalibrationNode == myNodeId);
    critical_section_exit(&commStateLock);
    
    if (!canStartCalibration) {
        Serial.println("ERROR: Cannot start calibration - another node is currently calibrating");
        return;
    }
    
    
    // Mark ourselves as the active calibration node
    critical_section_enter_blocking(&commStateLock);
    commState.activeCalibrationNode = myNodeId;
    commState.calibrationInProgress = true;
    commState.calLastStepTime = millis();
    critical_section_exit(&commStateLock);

    Serial.println("Starting self-calibration...");
    
    // Before proceeding, broadcast our status to make sure other nodes know we're calibrating
    sendControlCommand(CAN_ADDR_BROADCAST, CAL_CMD_START_NODE, myNodeId);
    delay(1000); // Give other nodes time to process this message

    // Initialize calibration state
    critical_section_enter_blocking(&commStateLock);
    commState.calibrationInProgress = true;
    commState.calLastStepTime = millis();
    
    // Clear any previous coupling gains
    commState.couplingGains.clear();
    
    // Disable feedback control during calibration
    controlState.feedbackControl = false;
    critical_section_exit(&commStateLock);

    // Step 1: Turn off own LED
    setLEDDutyCycle(0.0f);
    
    // Step 2: Wait for light to stabilize to get a baseline reading
    Serial.println("Measuring baseline illuminance...");
    bool stabilized = waitForLightStabilization(5000, 0.1);
    
    if (!stabilized) {
        Serial.println("Warning: Light didn't fully stabilize for baseline reading");
        // Wait a fixed time as fallback
        delay(2000);
    }
    
    // Step 3: Take the baseline measurement
    float baselineLux = 0.0;
    const int SAMPLES = 5;
    const int STABILIZE_TIME = 500;
    
    for (int i = 0; i < SAMPLES; i++) {
        baselineLux += readLux();
        delay(STABILIZE_TIME / SAMPLES);
    }
    baselineLux /= SAMPLES;
    
    // Store baseline reading
    critical_section_enter_blocking(&commStateLock);
    sensorState.baselineIlluminance = baselineLux;
    critical_section_exit(&commStateLock);
    
    Serial.print("Baseline illuminance: ");
    Serial.print(baselineLux, 2);
    Serial.println(" lux");
    
    // Step 4: Turn on our own LED
    setLEDDutyCycle(1.0f);
    delay(1000); // Allow some time for the LED to turn on
    
    // Step 5: Broadcast that we've turned on our LED so other nodes can measure their cross-gains
    sendControlCommand(CAN_ADDR_BROADCAST, CAL_CMD_LED_ON, myNodeId);
    Serial.println("LED turned ON, notifying other nodes");
    
    // Step 6: Wait for our own light to stabilize
    Serial.println("Waiting for self-illuminance to stabilize...");
    stabilized = waitForLightStabilization(10000, 0.1);


    if (!stabilized) {
        Serial.println("Warning: Light didn't fully stabilize for self-gain measurement");
        delay(3000); // Wait a fixed time as fallback
    }
    
    // Step 7: Measure our self-gain
    float onLux = 0.0;
    for (int i = 0; i < SAMPLES; i++) {
        onLux += readLux();
        delay(STABILIZE_TIME / SAMPLES);
    }
    onLux /= SAMPLES;
    
    // Step 8: Calculate and store our LED gain
    float selfGain = onLux - baselineLux;
    deviceConfig.ledGain = (selfGain > 0.0f) ? selfGain : 0.1f; // Ensure positive gain
    
    Serial.print("Self-gain measurement: ");
    Serial.print(deviceConfig.ledGain, 2);
    Serial.println(" lux");

    delay(5000); // Give some time for other nodes to process the LED ON message
    
    // Step 9: Turn off our LED
    setLEDDutyCycle(0.0f);
    
    // Step 10: Broadcast that we've turned off our LED
    sendControlCommand(CAN_ADDR_BROADCAST, CAL_CMD_LED_OFF, myNodeId);
    Serial.println("LED turned OFF, notifying other nodes");
    
    // Wait a moment before updating the calibration state
    delay(1000);
    
    // Mark our part of the calibration as complete
    // In the final part where you notify others you've finished:
    critical_section_enter_blocking(&commStateLock);
    commState.calibrationState = CAL_FINISHED_SELF;
    critical_section_exit(&commStateLock);
    
    // When done, notify other nodes that we've finished
    sendControlCommand(CAN_ADDR_BROADCAST, CAL_CMD_FINISHED, myNodeId);
    Serial.println("Self-calibration complete - notifying other nodes");

    //Remoeve ourselves from the calibration queue
    auto it = std::remove(calibrationQueue.begin(), calibrationQueue.end(), myNodeId);
    if (it != calibrationQueue.end()) {
        calibrationQueue.erase(it, calibrationQueue.end());
    }
}

/**
 * Handle incoming calibration control message for decentralized calibration
 *
 * @param sourceNodeId ID of the node that sent the message
 * @param controlType Type of calibration command
 * @param value Command parameter value
 */
void handleCalibrationMessage(uint8_t sourceNodeId, uint8_t controlType, float value) {
    switch (controlType) {
        case CAL_CMD_INIT: {
            uint8_t initiatingNode = (uint8_t)value;
    
            // Clear existing queue
            calibrationQueue.clear();
            
            // Always put initiating node first
            calibrationQueue.push_back(initiatingNode);
            
            // Then add ourselves if we're not the initiating node
            if (deviceConfig.nodeId != initiatingNode) {
                calibrationQueue.push_back(deviceConfig.nodeId);
            }
            
            // Add other active neighbors
            for (int i = 0; i < MAX_NEIGHBORS; i++) {
                if (neighbors[i].isActive && 
                    neighbors[i].nodeId != deviceConfig.nodeId && 
                    neighbors[i].nodeId != initiatingNode) {
                    calibrationQueue.push_back(neighbors[i].nodeId);
                }
            }
            
            // Sort remaining nodes (except initiating node) for consistency
            if (calibrationQueue.size() > 1) {
                std::sort(calibrationQueue.begin() + 1, calibrationQueue.end());
            }
            
            // Reset calibration state
            critical_section_enter_blocking(&commStateLock);
            commState.calibrationInProgress = true;
            commState.calLastStepTime = millis();
            commState.activeCalibrationNode = 0; // No node is actively calibrating yet
            commState.calibrationState = CAL_WAITING_FOR_TURN;
            commState.crossGainAcks.clear(); // Clear any previous acks
            critical_section_exit(&commStateLock);
            
            // Print the calibration queue
            Serial.print("Initial calibration queue: ");
            for (uint8_t nodeId : calibrationQueue) {
                Serial.print(nodeId);
                Serial.print(" ");
            }
            Serial.println();
            
            // Only the initiating node should trigger calibration start
            if (initiatingNode == deviceConfig.nodeId) {
                // If our node is first in queue, start calibration after a delay
                if (!calibrationQueue.empty() && calibrationQueue.front() == deviceConfig.nodeId) {
                    Serial.println("I am first in queue - starting calibration in 3 seconds");
                    delay(3000);
                    startSelfCalibration();
                }
            }
            
            break;
        }
        case CAL_CMD_START_REQUEST: {
            uint8_t requestingNode = (uint8_t)value;
            
            // Add to queue if not already there
            bool alreadyQueued = false;
            for (uint8_t nodeId : calibrationQueue) {
                if (nodeId == requestingNode) {
                    alreadyQueued = true;
                    break;
                }
            }
            
            if (!alreadyQueued) {
                calibrationQueue.push_back(requestingNode);
                // Sort the queue to ensure deterministic order across all nodes
                std::sort(calibrationQueue.begin(), calibrationQueue.end());
                
                Serial.print("Node ");
                Serial.print(requestingNode);
                Serial.println(" added to calibration queue");
                
                Serial.print("Current queue: ");
                for (uint8_t nodeId : calibrationQueue) {
                    Serial.print(nodeId);
                    Serial.print(" ");
                }
                Serial.println();
            }
            break;
        }
        case CAL_CMD_START_NODE: {
            uint8_t startingNode = (uint8_t)value;
            
            Serial.print("Node ");
            Serial.print(startingNode);
            Serial.println(" is starting its calibration");
            
            // Force all nodes to recognize only this node as calibrating
            critical_section_enter_blocking(&commStateLock);
            commState.activeCalibrationNode = startingNode;
            commState.calibrationInProgress = true;
            commState.calLastStepTime = millis();
            critical_section_exit(&commStateLock);
            
            // If this message is targeting us, start our calibration!
            if (startingNode == deviceConfig.nodeId) {
                Serial.println("We've been signaled to start our calibration. Starting in 1 second...");
                delay(1000);
                startSelfCalibration();
            }
            // Otherwise, turn our LED OFF to not interfere
            else {
                setLEDDutyCycle(0.0f);
            }
            
            break;
        }
        case CAL_CMD_FINISHED: {
            uint8_t finishedNode = (uint8_t)value;
            
            Serial.print("Node ");
            Serial.print(finishedNode);
            Serial.println(" has finished calibration");
            
            // Mark that no node is calibrating
            critical_section_enter_blocking(&commStateLock);
            commState.activeCalibrationNode = 0;
            critical_section_exit(&commStateLock);
            
            lastCalibrationTime = millis();
            
            // Remove the finished node from queue
            bool wasRemoved = false;
            for (auto it = calibrationQueue.begin(); it != calibrationQueue.end(); ) {
                if (*it == finishedNode) {
                    it = calibrationQueue.erase(it);
                    wasRemoved = true;
                    break;
                } else {
                    ++it;
                }
            }
            
            // Print updated queue regardless if node was removed
            Serial.print("Updated queue: ");
            for (uint8_t nodeId : calibrationQueue) {
                Serial.print(nodeId);
                Serial.print(" ");
            }
            Serial.println();
            
            // If queue is empty, we're done with calibration - broadcast completion
            if (calibrationQueue.empty()) {
                Serial.println("Calibration queue empty - all nodes calibrated");
                // Always notify when queue is empty, even if this node wasn't removed
                sendControlCommand(CAN_ADDR_BROADCAST, CAL_CMD_COMPLETE, deviceConfig.nodeId);
                delay(500);  // Give time for message to be sent
                finishCalibration();
                break;
            }
            
            // IMPORTANT CHANGE: Only the just-finished node should coordinate the next step
            // This prevents multiple nodes from sending conflicting commands
            if (deviceConfig.nodeId == finishedNode) {
                // Check if there's a next node in queue
                if (!calibrationQueue.empty()) {
                    uint8_t nextNode = calibrationQueue.front();
                    Serial.print("Next node in queue: ");
                    Serial.println(nextNode);
                    
                    // Signal the next node to start its calibration
                    Serial.print("Sending START_NODE signal to node ");
                    Serial.println(nextNode);
                    sendControlCommand(CAN_ADDR_BROADCAST, CAL_CMD_START_NODE, nextNode);
                }
            }
            // If we're the next in queue, don't start yet - wait for the START_NODE signal
            else if (!calibrationQueue.empty() && calibrationQueue.front() == deviceConfig.nodeId) {
                Serial.println("We are next in calibration queue. Waiting for START_NODE signal...");
            }
            break;
        }
        case CAL_CMD_COMPLETE: {
            uint8_t initiatingNode = (uint8_t)value;
            
            Serial.print("Complete calibration notification from node ");
            Serial.println(initiatingNode);
            
            // Finish our calibration process regardless of our state
            finishCalibration();
            break;
        }
        case CAL_CMD_LED_ON: {
            uint8_t nodeId = (uint8_t)value;
            
            Serial.print("Node ");
            Serial.print(nodeId);
            Serial.println(" turned ON its LED for calibration");
            
            // Ensure our own LED is OFF to not interfere
            setLEDDutyCycle(0.0f);
            
            // Make sure we're in calibration mode
            critical_section_enter_blocking(&commStateLock);
            bool inCalibration = commState.calibrationInProgress;
            critical_section_exit(&commStateLock);
            
            if (!inCalibration) {
                // If not already in calibration mode, enter it
                critical_section_enter_blocking(&commStateLock);
                commState.calibrationInProgress = true;
                commState.calLastStepTime = millis();
                critical_section_exit(&commStateLock);
            }

            // Wait for light to stabilize
            delay(5000);
            
            // Measure illuminance with this node's LED on
            float lux = 0.0;
            const int SAMPLES = 5;
            for (int i = 0; i < SAMPLES; i++) {
                lux += readLux();
                delay(100);
            }
            lux /= SAMPLES;
            
            // Get our baseline illuminance
            critical_section_enter_blocking(&commStateLock);
            float baselineLux = sensorState.baselineIlluminance;
            critical_section_exit(&commStateLock);
            
            // Calculate coupling gain (how much this node's LED affects our sensor)
            float couplingGain = lux - baselineLux;

            Serial.print("Coupling gain from node ");
            Serial.print(nodeId);
            Serial.print(": ");
            Serial.print(couplingGain, 2);
            Serial.println(" lux");
        
            // Store it if it's positive (negative would be measurement noise)
            if (couplingGain > 0.0f) {
                critical_section_enter_blocking(&commStateLock);
                commState.couplingGains[nodeId] = couplingGain;
                critical_section_exit(&commStateLock);
                
                Serial.print("Coupling gain from node ");
                Serial.print(nodeId);
                Serial.print(": ");
                Serial.print(couplingGain, 2);
                Serial.println(" lux");
                
                // Send explicit ACK with measured gain
                sendControlCommand(nodeId, CAL_CMD_CROSS_GAIN_ACK, couplingGain);
            } else {
                Serial.print("WARNING: Negative or zero coupling gain detected from node ");
                Serial.print(nodeId);
                Serial.print(": ");
                Serial.println(couplingGain, 4);
                
                // Still store it for debugging
                critical_section_enter_blocking(&commStateLock);
                commState.couplingGains[nodeId] = 0.01f;  // Small positive value as fallback
                critical_section_exit(&commStateLock);
            }
            break; 
        }
        case CAL_CMD_LED_OFF: {
            uint8_t nodeId = (uint8_t)value;
            Serial.print("Node ");
            Serial.print(nodeId);
            Serial.println(" turned OFF its LED after calibration");
            
            // Wait for light to stabilize again
            delay(1000);
            
            // Check if we should complete our calibration
            // This is a simple timeout-based approach - if no calibration messages 
            // received for a while, assume all nodes are done
            static unsigned long lastCalMessage = 0;
            unsigned long now = millis();
            lastCalMessage = now;
            
            // Let's schedule a check in the future
            delay(100);
            if ((now - lastCalMessage) > 10000) {
                // No calibration messages for 10 seconds, probably done
                finishCalibration();
            }
            break;
        }
        case CAL_CMD_CROSS_GAIN_ACK: {
            uint8_t ackNodeId = sourceNodeId;
            float gainValue = value;
            
            Serial.print("Received cross-gain ACK from node ");
            Serial.print(ackNodeId);
            Serial.print(" with value: ");
            Serial.println(gainValue, 2);
            
            // Store the acknowledgment
            critical_section_enter_blocking(&commStateLock);
            commState.crossGainAcks[ackNodeId] = true;
            commState.calLastStepTime = millis(); // Reset timeout
            critical_section_exit(&commStateLock);
            
            // Check if we've received acks from all nodes in our queue
            bool allAcksReceived = true;
            critical_section_enter_blocking(&commStateLock);
            for (uint8_t nodeId : calibrationQueue) {
                // Skip ourselves
                if (nodeId == deviceConfig.nodeId) continue;
                
                // If we're missing an ack from any node, we're not done
                if (!commState.crossGainAcks.count(nodeId) || !commState.crossGainAcks[nodeId]) {
                    allAcksReceived = false;
                    break;
                }
            }
            critical_section_exit(&commStateLock);
            
            // If all acks received, we can proceed to the next step
            if (allAcksReceived && commState.calibrationState == CAL_MEASURING_OTHERS) {
                Serial.println("All cross-gain measurements acknowledged");
                // Proceed to finish calibration or next node
                if (calibrationQueue.empty()) {
                    sendControlCommand(CAN_ADDR_BROADCAST, CAL_CMD_COMPLETE, deviceConfig.nodeId);
                    finishCalibration();
                } else {
                    // Move to the next node in queue
                    if (!calibrationQueue.empty() && calibrationQueue.front() == deviceConfig.nodeId) {
                        // Our turn is next
                        startSelfCalibration();
                    }
                }
            }
            break;
        }
    }
}

/**
 * Finish the calibration process and return to normal operation
 */
void finishCalibration() {
    // Only allow finish once per wake-up cycle
    critical_section_enter_blocking(&commStateLock);
    if (commState.calibrationState == CAL_COMPLETE) {
        Serial.println("Already finished calibration. Ignoring duplicate call.");
        critical_section_exit(&commStateLock);
        return;
    }
    commState.calibrationState = CAL_COMPLETE;
    critical_section_exit(&commStateLock);
    // Print results
    Serial.println("\n===============================");
    Serial.println("   CALIBRATION COMPLETE");
    Serial.println("===============================");
    Serial.print("Node ID: ");
    Serial.println(deviceConfig.nodeId);
    Serial.print("Self-gain: ");
    Serial.print(deviceConfig.ledGain, 2);
    Serial.println(" lux");
    
    critical_section_enter_blocking(&commStateLock);
    Serial.print("Baseline illuminance: ");
    Serial.print(sensorState.baselineIlluminance, 2);
    Serial.println(" lux");
    
    Serial.println("\nCoupling gains (effect of other LEDs on this node):");
    int gainCount = 0;
    for (const auto& pair : commState.couplingGains) {
        Serial.print("  Node ");
        Serial.print(pair.first);
        Serial.print(" → Node ");
        Serial.print(deviceConfig.nodeId);
        Serial.print(": ");
        Serial.print(pair.second, 2);
        Serial.println(" lux");
        gainCount++;
    }
    
    if (gainCount == 0) {
        Serial.println("  WARNING: No coupling gains measured from other nodes!");
    }
    
    // Return to normal operation
    commState.calibrationInProgress = false;
    commState.wasCalibrating = true;
    commState.calibrationCompleted = true; // Mark calibration as completed
    controlState.luminaireState = STATE_UNOCCUPIED;
    controlState.setpointLux = SETPOINT_UNOCCUPIED;
    controlState.feedbackControl = true;
    controlState.systemReady = true;
    critical_section_exit(&commStateLock);
    
    // Set initial duty cycle
    float initialDuty = SETPOINT_UNOCCUPIED / deviceConfig.ledGain;
    initialDuty = constrain(initialDuty, 0.1f, 0.7f);
    setLEDDutyCycle(initialDuty);
    
    // Update control state
    critical_section_enter_blocking(&commStateLock);
    controlState.dutyCycle = initialDuty;
    critical_section_exit(&commStateLock);
    
    // Reset PID controller to avoid transients
    pid.reset();
    
    Serial.println("Calibration complete - resuming normal operation");
}

bool waitForLightStabilization(unsigned long maxWaitTime, float stabilityThreshold) {
    const int NUM_SAMPLES = 5;             // Number of samples to check stability
    const int SAMPLE_INTERVAL = 300;       // Time between samples (ms)
    float samples[NUM_SAMPLES] = {0.0f};   // Array to store samples
    int sampleIndex = 0;                   // Current sample index
    
    unsigned long startTime = millis();    // Start time for timeout
    
    // Initialize the sample array with initial readings
    for (int i = 0; i < NUM_SAMPLES; i++) {
        samples[i] = readLux();
        delay(SAMPLE_INTERVAL);
    }
    
    // Loop until timeout or stabilization
    while ((millis() - startTime) < maxWaitTime) {
        // Take a new reading and replace oldest
        float newReading = readLux();
        samples[sampleIndex] = newReading;
        sampleIndex = (sampleIndex + 1) % NUM_SAMPLES;
        
        // Check if readings have stabilized
        float minValue = samples[0];
        float maxValue = samples[0];
        float sum = samples[0];
        
        for (int i = 1; i < NUM_SAMPLES; i++) {
            minValue = min(minValue, samples[i]);
            maxValue = max(maxValue, samples[i]);
            sum += samples[i];
        }
        
        float avgValue = sum / NUM_SAMPLES;
        float range = maxValue - minValue;
        float relativeRange = range / avgValue;
        
        // If relative range is small enough, light has stabilized
        if (relativeRange < stabilityThreshold) {
            unsigned long stabilizationTime = millis() - startTime;
            Serial.print("Light stabilized after ");
            Serial.print(stabilizationTime);
            Serial.println(" ms");
            return true;
        }
        
        delay(SAMPLE_INTERVAL);
    }
    
    // Timeout occurred
    Serial.println("Light stabilization timed out");
    return false;
}

void updateCalibrationState() {
    unsigned long currentTime = millis();
    static unsigned long calibrationStartTime = 0;
    
    // Check if calibration is active
    critical_section_enter_blocking(&commStateLock);
    bool calibrationActive = commState.calibrationInProgress;
    unsigned long lastStepTime = commState.calLastStepTime;
    uint8_t activeNode = commState.activeCalibrationNode;
    bool queueEmpty = calibrationQueue.empty();
    critical_section_exit(&commStateLock);

    if (!calibrationActive) {
        return;
    }
}
