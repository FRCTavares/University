#ifndef CALIBRATION_H
#define CALIBRATION_H

#include <Arduino.h>
#include "Globals.h"
#include <vector>

// Expose these variables for use in SCDTR.ino
extern std::vector<uint8_t> calibrationQueue;
extern unsigned long lastCalibrationTime;

/**
 * Start self-calibration process in a decentralized manner
 * Each node calibrates itself without a master node coordinating
 */
void startSelfCalibration();

/**
 * Finish the calibration process and return to normal operation
 */
void finishCalibration();

bool waitForLightStabilization(unsigned long maxWaitTime, float stabilityThreshold);


//==========================================================================================================================================================
// DISPLAY FUNCTIONS
//==========================================================================================================================================================

/**
 * Handle an incoming calibration control message
 *
 * @param sourceNodeId ID of the node that sent the message
 * @param controlType Type of calibration command
 * @param value Command parameter value
 */
void handleCalibrationMessage(uint8_t sourceNodeId, uint8_t controlType, float value);

#endif // CALIBRATION_H